WAMEED / وميض — see README_AR.md for setup and deployment.
Never publish Supabase service_role keys in frontend files.
