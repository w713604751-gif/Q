/* إعداد Supabase: ضع رابط المشروع ومفتاح anon/publishable فقط. ممنوع وضع service_role هنا. */
window.WAMEED_CONFIG={SUPABASE_URL:"",SUPABASE_ANON_KEY:""};
